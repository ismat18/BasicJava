package Learning_Static;

public class Catching_Learning_Static_Method {

	public static void main(String[] args) {
		
		Learning_Static_Method P1 = new Learning_Static_Method();
		P1.display1();
		
		Learning_Static_Method.display2();
		

	}

}
