package Learning_Static;

public class Catching_Learning_Static_Block {

	public static void main(String[] args) {
	
		
		Learning_Static_Block.display();
		
	}

}
