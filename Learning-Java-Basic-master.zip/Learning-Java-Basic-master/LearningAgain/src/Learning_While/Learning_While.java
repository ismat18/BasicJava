package Learning_While;

public class Learning_While {

	public static void main(String[] args) {
		//initialization, condition, increment/decrement
		
		int x =1;
		while (x<=15) {
			System.out.println("This is correct");
			x++;
		}
		
		int i = 4;
		
		do {
			System.out.println("Hello");
			i++;
			
		}while(i<10);

	}

}
