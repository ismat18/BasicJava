package Learning_Access_Modifier;

public class Catching_Learning_Access_Modifier {

	public static void main(String[] args) {
		Learning_Access_Modifier abc = new Learning_Access_Modifier();
		abc.Printweek();
		System.out.println(abc.Printweek());
		
		

	}

}
