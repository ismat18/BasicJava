package Learning_Abstract;

public class Catching_Learning_Abstract {

	public static void main(String[] args) {
		Learning_Abstract M;
		M = new Learning_Abstract_1();
		M.hello();
		M.hiprint();

	}

}
