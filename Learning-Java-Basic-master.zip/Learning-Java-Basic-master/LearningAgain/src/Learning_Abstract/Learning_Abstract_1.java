package Learning_Abstract;

public class Learning_Abstract_1 extends Learning_Abstract{
	
	void hello() {
		System.out.println("Hi there");
	}

}
