package Learning_Method;

public class Catching_Learning_Method_Over_riding{

	public static void main(String[] args) {
		
		Lrarning_Method_Over_riding P1 = new Lrarning_Method_Over_riding();
		P1.name = "Jim";
		P1.age = 30;
		P1.display();
		
		Lrarning_Method_Over_riding_1 P2 = new Lrarning_Method_Over_riding_1();
		P2.name = "Paul";
		P2.age = 40;
		P2.address ="303 East camp wisdom road";
		P2.display();
		
		
		
		
		
		
		
		
		
		
		
		
		
		

//		Lrarning_Method_Over_riding abc = new Lrarning_Method_Over_riding();
//		display();
//		abc.answer();
		
		
		 
			
	}
	
//	 public static void display() {
//		   System.out.println("Hi");
//	   }
//      
//     void answer() {
//		   System.out.println("Getting the answer");
//	   }
}
