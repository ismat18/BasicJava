package Learning_Method;

public class Lrarning_Method_Over_riding_1 extends Lrarning_Method_Over_riding{
	
	String address;
	
	void display() {
		
		System.out.println(name);
		System.out.println(age);
		System.out.println(address);
	}

}
