package Learning_Method;

public class Lrarning_Method_Over_riding{

		//Cannot override static Method  - because Static method is bound to class and Non Staic method is bound to object
		// Need to Inheritance for Method Overrididng.
	
	//Method overloading vs Metod over riding
	
		//Method overloading hapens in same class vs Methos overriding hapens in multiple class
		//Method overloading parameterized must be different vs Method overriding parameterized must be same
		//Method overloading does not need Inheritance vs Method overriding has Inheritance.
		//Method overloading return type may not be the same vs Method overriding Method return type must be same
	
	String name;
	int age;
	
	void display() {
		System.out.println(name);
		System.out.println(age);
	}
	
	
	
	
	
	
	
	
	
	
	
//	public static void display() {
//		
//		System.out.println("Hi There");
//	}
//     
//	void answer() {
//		System.out.println("Seeking answer");
//	}
      	
    }
	
	


