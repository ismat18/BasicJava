package Learning_This;

public class Catching_Learning_this {

	public static void main(String[] args) {
		
		Learning_this P1 = new Learning_this("Pavel", 42);
		P1.display();
		
		Learning_this P2 = new Learning_this("Paul", 30, "Black");
	    P2.display();
	   
	    
	  // Learning_this P3 = new Learning_this();
	  // P3.display();// Will print display(), and yes() Method
	     

	}

	
}
