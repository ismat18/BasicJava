package Learning_Polymorphism;

public class Student extends Person {
	
	
	void display() {
		System.out.println("I am a Student");
	
	}

}
