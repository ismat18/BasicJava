package Learning_Polymorphism;

public class Person {
	//Polymorphism is a mechasim where a parent class reference variable can refer object from different class
	//person p = new teacher();
	//Compile type Polymorphism - is Method and Constractor Overloading
	//Run time Polymorphism - is Method overriding
	
	void display() {
		System.out.println("I am a Person");
	}

}
