package Learning_Polymorphism;

public class Shape {
	
	double something = 50;
	double area() {
		
		System.out.print("Area for shape : ");
		return something;
	}

}
