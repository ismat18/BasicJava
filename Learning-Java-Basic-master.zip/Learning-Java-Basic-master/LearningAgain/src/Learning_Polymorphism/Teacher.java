package Learning_Polymorphism;

public class Teacher extends Person{
	//inherited display Method
	
	void display() {
	System.out.println("I am a Teacher");
	}
	

}
