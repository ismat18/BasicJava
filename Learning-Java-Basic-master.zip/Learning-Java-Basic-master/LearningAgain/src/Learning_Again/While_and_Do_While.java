package Learning_Again;

public class While_and_Do_While {

	public static void main(String[] args) {
		
		//While
		int x = 1;
		while(x<=5) {
			System.out.println("Hello");
			x++;
		}
		
		
		//Do While
		int i=1;
				
		do {
			System.out.println(i);
			i=i+2;//
		}while (i<=10);
		
		
//		do {
//			System.out.println(i);
//			i++;
//		} while (i<=15);
//
//		int j=10;
//		do {
//			System.out.println(j);
//			j++;
//			
//		}while (j<=20);
		
		
	}
	
	

}
