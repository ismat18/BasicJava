package Learning_Again;

public class Learning_Array {

	public static void main(String[] args) {//An array is a collection of variables of same data type
	//  int[]number = {10,20,30};
	//  for(int i=0;i<number.length;i++) {
    //		  System.out.println(number[i]);
		
//	     int arr[]=new int[] {10,20,30,40,50,70};
//			for (int x=0;x<arr.length;x++) {
//				System.out.println(arr[x]);
	     
			//}
		
		
//	    String[]name = new String[3];
//		name[0]="paul";
//		name[1]="john";
//		name[2]="andrew";
	//	
//		//for (int i=0;i<name.length;i++) {
//		for (String N:name)	{
//			System.out.println(N);
//		}
	//	
	}

}
