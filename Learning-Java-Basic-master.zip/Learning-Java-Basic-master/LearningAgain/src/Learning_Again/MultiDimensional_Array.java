package Learning_Again;

public class MultiDimensional_Array {
	
	public static void main(String[] args) {
	
		int [][]grid= {
				{2,4,5},
				{6,7},
				{8,9,10}
				
		};
//		
		System.out.println(grid[2][1]);
//		
//		for (int j=0;j<grid.length;j++) {
//		for (int k=0;k<grid[j].length;k++) {
//				
//		System.out.println(grid[j][k]);
//			
//			
//			}
//		}
//		
//		
//		String [][]flights = new String[4][4];
//
////		// first Row
//	    flights[0][0] = "Dallas";
//		flights[0][1] = "NYC";
//		flights[0][2] = "Miami";
//		flights[0][3] = "Chicago";
//
////		// Second Row
//		flights[1][0] = "New Mexico";
//		flights[1][1] = "San Diego";
//		flights[1][2] = "DC";
//		flights[1][3] = "Newark";
//
//		// Third Row
//
//		flights[2][0] = "New Orleans";
//		flights[2][1] = "Baton Rouge";
//		flights[2][2] = "Kansas";
//		flights[2][3] = "Toronto";
//
//		// Fourth Row
//
//		flights[3][0] = "Denvar";
//		flights[3][1] = "Honolulu";
//		flights[3][2] = "Harrisburg";
//		flights[3][3] = "Houston";
//		
//		for (int row=0;row<flights.length;row++) {
//			for(int col=0;col<flights[row].length;col++) {
//				
//				System.out.println(flights[row][col]);
//			}
//			
//		}
//		
		
		int arr[]=new int[] {10,20,30,40,50,70};
		for (int x=0;x<arr.length;x++) {
			System.out.println(arr[x]);
		}
			
		
	}

}
