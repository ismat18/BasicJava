package Learning_Again;

public class For_Loop {

	public static void main(String[] args) {
		
//		for (int i=0;i<5;i++) {
//			System.out.println(i);
//		}
	     

//		for (x=0;x<15;x++) {
//		System.out.println(x);	
//		
//		}
//		
//		for(int g=0;g<2;g++) {
//			System.out.println("Hello");
//		}
//		
//		int[]number = new int[3];
//		number[0]=10;
//		number[1]=20;
//		number[2]=30;
//		//System.out.println(number[0]);	
//		//System.out.println(number.length);
////		for(int d=0;d<number.length;d++) {
////			System.out.println(number[d]);
//	//	OR
//		for (int f:number) {
//			System.out.println(f);
//		}
		
		int num[]= {10,20,30};
		for (int i=0;i<num.length;i++) {
			System.out.println(num[i]);
    	}
	     int arr[]=new int[] {10,20,30,40,50,70};
    	for (int x=0;x<arr.length;x++) {
		System.out.println(arr[x]);
	    
    	}
		
		String[]bird = {"parrot","tia","bulbuli"};
		for (String t:bird) {
			System.out.println(t);
		}
		
		int [][]value = {{10,20,30},{40,50},{60,70}};
		
		for (int row = 0;row<value.length;row++) {
			for (int col =0;col<value[row].length;col++) {
				System.out.println(value[row][col]);
			}
		}
		
		
//for (int i=0;i<5;i++) {
//	System.out.println(i);
//}

//  for (x=0;x<7;x++) {
//	  System.out.println(x);
//  }
//
//  int[]number = {10,20,30};
//  for(int i=0;i<number.length;i++) {
//	  System.out.println(number[i]);
//  }
//     int [][]numbers = {{10,20,30},{40,50},{60,70,80}};
//   //  System.out.println(numbers[1][0]);
//    
//     for (int row=0;row<numbers.length;row++) {
//     for(int col=0;col<numbers[row].length;col++) {
//    		 
//     System.out.println(numbers[row][col]);
//    	 }
//     }
//	
//     int arr[]=new int[] {10,20,30,40,50,70};
//		for (int x=0;x<arr.length;x++) {
//			System.out.println(arr[x]);
     
		//}
    
		
		
//		
//    String[]name = new String[3];
//	name[0]="paul";
//	name[1]="john";
//	name[2]="andrew";
//	
//	//for (int i=0;i<name.length;i++) {
//	for (String N:name)	{
//		System.out.println(N);
//	}
//	
		
	}
}
	
	

