package Learning_Again;

public class Other {
	public static void main(String[] args) {
   	 
		//JRE and JDK
		//Edit, Compile, Load, Varify, Execute
		//Text Editor - Saves as .Java
		// Compiler - changes to Bite code .class(JVM)
		//Then Loads
		//Then verify if it is Java code
		// Execute - Java vertual Machine executes the code. 
		//JRE - Java run time environment. Whenever you run it JRE get called. Insie JRE there is Jvm
		//(Jave virtual Machine) which creates memory for variablec and methods. It converts the program into Bytes
		//JDK - Java Development Kit - Sets up Java path into the machine.
		
		
		//Variable and Data Type
		//Data Type: Primitive and Non Primitive:
		//Primitive: Boolean, Char, Byte, Short, Int, Long, Float and Double
		//Non - Primitive: String, Array
		
		//Escape Sequence
		//Need to be inside ""
		// \b, \t, \n, \r, \", \', \\
		// \b - backspace
		// System.out.println("Hello World 10 \b");
		// \t - tab
		// System.out.println("1 \t 2");
		
		// \n - new line
		// System.out.println("Hello world \n phone number:917-213-3776");
		
		// \\ - double qotations
		// System.out.println("\"Paul\"");
		
		// \r - Carriage Return
		
		// list ,set, map
		
	   	 
	  }
}
