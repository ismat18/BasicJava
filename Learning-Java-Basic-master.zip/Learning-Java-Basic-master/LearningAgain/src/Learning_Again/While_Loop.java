package Learning_Again;

public class While_Loop {

	public static void main(String[] args) {
		
		int money = 10;
		
		while(money<100) {
			
			System.out.println(money);
			money++;
		}

	}
	
	
	

}
