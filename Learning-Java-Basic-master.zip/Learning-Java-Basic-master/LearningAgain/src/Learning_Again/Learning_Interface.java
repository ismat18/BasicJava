package Learning_Again;

public interface Learning_Interface {

	//Wbdriver, list, Hashmaps
	//same as class but it does have body (only has method declaration)
	//By default interface is public and abstruct
	
	public int age(int age);//Abstract. does not have body just declaration of method
	
	public int num();
	
	//abstract with keywords
	
	int numberVales();//does not have body just declaration of method
	
	abstract public String name();//same as above
	
	//non abstract is same as regular class method which has body.
}
