package Learning_Interface;

public class Catching_Learning_Interface {

	public static void main(String[] args) {
		
		Learning_Interface_1 P1 = new Learning_Interface_1();
		P1.eat();
		//Learning_Interface P2 = new Learning_Interface(); - cannot create object for interface class.
		//Learning_Interface P2; - can create reference variable

	}

}
