package Learning_Interface;

public class Learning_Interface_1 implements Learning_Interface{
	
	public void eat() {//Need to use all the abstract Method. Need to use the word public
		
		System.out.println("Printing abstrac method");
	}

}
