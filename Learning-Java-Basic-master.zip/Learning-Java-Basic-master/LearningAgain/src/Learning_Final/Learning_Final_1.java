package Learning_Final;

public class Learning_Final_1 extends Learning_Final{
	
//	void result() {//cannot override static method
//		super.result();
//		
//		System.out.println("Hello there");
//		
//	}

	//but it can be inherited
	
	void result1() {
		System.out.println("Hello");
	}
	
}
