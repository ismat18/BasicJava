package Learning_Final;

public class Catching_Learning_Final {

	public static void main(String[] args) {
		
		Learning_Final P1 = new Learning_Final();
		P1.display();
		
		Learning_Final_1 P2 = new Learning_Final_1();
		P2.result();//inherited
		P2.result1();
		
		
		
		
		
	}

}
