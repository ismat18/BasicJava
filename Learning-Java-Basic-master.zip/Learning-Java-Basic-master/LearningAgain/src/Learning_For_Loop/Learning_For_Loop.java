package Learning_For_Loop;

public class Learning_For_Loop {

	public static void main(String[] args) {
		
		//initialization; condition; increment/decrement.
		
		for(int x=0;x<10;x++) {
		
		System.out.println(x);
		
		}
	}

}
